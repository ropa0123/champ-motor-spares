// This line loads environment variables from a .env file.
require('dotenv').config();

// We're setting up a web server using the Express framework.
const express = require('express');
const app = express();

// body-parser is used to process data sent in the body of HTTP requests.
const bodyParser = require('body-parser');
app.use(bodyParser.json());

// Set up a simple route to handle payment processing.
app.post('/process-payment', (req, res) => {
    // We get the secret key from an environment variable.
    // The name of the environment variable (e.g., 'PAYMENT_SECRET_KEY') 
    // is defined in your .env file.
    const secretKey = process.env.PAYMENT_SECRET_KEY;
    const { items } = req.body;

    // Check if the secret key is configured.
    if (!secretKey) {
        return res.status(500).json({ success: false, message: "Server-side payment key is not configured." });
    }

    // In a real application, you would perform the payment gateway API call here.
    // This part of the code communicates with the payment provider's API.
    console.log('Processing payment request with items:', items);
    
    // This is the correct way to log the key to confirm it's being used,
    // without exposing it directly in the code.
    console.log('Using secret key:', secretKey ? 'Key is configured' : 'Key not found');

    // After the successful API call, you would send a success response back to the client.
    res.json({ success: true, message: "Payment processed successfully!" });
});

// The express.static middleware serves your HTML, CSS, and client-side JavaScript files.
// Assuming your front-end files are in a folder named 'public' or something similar,
// you would change 'path.join(__dirname, 'public')' to match your directory structure.
const path = require('path');
app.use(express.static(path.join(__dirname, '..', 'public')));

// The server listens for incoming requests on a specific port.
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});